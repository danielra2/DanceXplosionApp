export{S as SafeLoggerProvider,e as evaluateTargetingAndCapture,f as flush,a as getSessionId,b as getSessionReplayProperties,i as init,s as setSessionId,c as shutdown}from"./index-min.js";import"./targeting-min.js";
//# sourceMappingURL=session-replay-browser-esm.js.map
