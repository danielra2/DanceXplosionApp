export{S as SessionReplayPlugin,s as plugin,s as sessionReplayPlugin}from"./index-min.js";
//# sourceMappingURL=plugin-session-replay-browser-esm.js.map
